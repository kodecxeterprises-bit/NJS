import fs from 'node:fs';

const appPath = 'src/App.tsx';
const sidebarPath = 'src/components/layout/Sidebar.tsx';
let app = fs.readFileSync(appPath, 'utf8');
let sidebar = fs.readFileSync(sidebarPath, 'utf8');

function replaceOnce(source, from, to, label) {
  if (!source.includes(from)) throw new Error(`Could not find expected ${label} section. No changes were written.`);
  return source.replace(from, to);
}

app = replaceOnce(app,
  "import { AiMatchesPage } from './pages/AiMatchesPage';",
  "import { AiAssistantPage } from './pages/AiAssistantPage';",
  'AI matches import');
app = replaceOnce(app,
  "import { AiLeadGeneratorPage } from './pages/AiLeadGeneratorPage';\n",
  '',
  'AI lead generator import');

app = replaceOnce(app,
  "  'ai-matches',",
  "  'ai-assistant',\n  'ai-matches',",
  'authenticated route list');
app = replaceOnce(app,
  "      {currentPath === 'ai-matches' && (\n        <AiMatchesPage\n          onNavigate={navigate}\n          initialBrief={navigationState?.initialBrief}\n        />\n      )}",
  "      {(currentPath === 'ai-assistant' || currentPath === 'ai-matches' || currentPath === 'ai-lead-generator' || currentPath === 'ai-outreach') && <AiAssistantPage />}",
  'AI page route rendering');
app = replaceOnce(app,
  "      {currentPath === 'ai-lead-generator' && <AiLeadGeneratorPage onNavigate={navigate} />}\n      {currentPath === 'ai-outreach' && <AiLeadGeneratorPage onNavigate={navigate} />}\n",
  '',
  'legacy AI route rendering');

const oldNav = `    { id: 'ai-matches', label: 'AI Matches', icon: 'auto_awesome' },`;
sidebar = replaceOnce(sidebar, oldNav,
  `    { id: 'ai-assistant', label: 'NJS AI Assistant', icon: 'auto_awesome' },`,
  'AI matches sidebar item');
sidebar = replaceOnce(sidebar,
  `    { id: 'ai-lead-generator', label: 'AI Lead Generator', icon: 'psychology' },\n    { id: 'ai-outreach', label: 'AI Outreach', icon: 'bolt' },\n`,
  '',
  'AI lead/outreach sidebar items');

fs.writeFileSync(appPath, app);
fs.writeFileSync(sidebarPath, sidebar);
console.log('NJS AI Assistant integrated. Legacy AI URLs now open the unified workspace.');
