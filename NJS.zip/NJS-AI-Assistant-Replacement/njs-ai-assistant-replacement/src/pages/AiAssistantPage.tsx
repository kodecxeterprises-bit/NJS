import React, { useState } from 'react';
import {
  Sparkles, Search, Building2, Users, Send, WandSparkles,
  ArrowRight, Loader2, CheckCircle2, AlertCircle, Copy, Save, RotateCcw,
  Target, BriefcaseBusiness, Globe2, Package, ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

type ToolId = 'workspace' | 'sourcing' | 'matching' | 'profile' | 'leads' | 'outreach';

const tools: { id: ToolId; title: string; description: string; icon: React.ElementType }[] = [
  { id: 'sourcing', title: 'Sourcing assistant', description: 'Turn a plain-language requirement into a structured sourcing brief.', icon: Package },
  { id: 'matching', title: 'Business matching', description: 'Find relevant businesses in the NJS network for your requirement.', icon: Target },
  { id: 'profile', title: 'Profile builder', description: 'Turn your business description into a clearer, richer profile draft.', icon: Building2 },
  { id: 'leads', title: 'Lead discovery', description: 'Discover matching businesses already registered on NJS.', icon: Users },
  { id: 'outreach', title: 'Outreach studio', description: 'Create and save a personalized B2B outreach draft.', icon: Send },
];

const inputClass = 'w-full rounded-xl border border-outline-variant bg-white px-4 py-3 text-sm text-on-surface outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/10';
const labelClass = 'mb-1.5 block text-xs font-semibold uppercase tracking-wide text-on-surface-variant';

export const AiAssistantPage: React.FC = () => {
  const { apiFetch, businessProfile, updateBusinessProfile } = useAuth();
  const [active, setActive] = useState<ToolId>('workspace');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [brief, setBrief] = useState('');
  const [parsed, setParsed] = useState<any>(null);
  const [matches, setMatches] = useState<any[]>([]);
  const [leadQuery, setLeadQuery] = useState('');
  const [leads, setLeads] = useState<any[]>([]);
  const [profileText, setProfileText] = useState(businessProfile?.businessDescription || '');
  const [profileDraft, setProfileDraft] = useState<any>(null);
  const [recipient, setRecipient] = useState('');
  const [company, setCompany] = useState('');
  const [goal, setGoal] = useState('Introduce a potential B2B partnership');
  const [tone, setTone] = useState('Professional and warm');
  const [draft, setDraft] = useState('');

  const run = async (task: () => Promise<void>) => {
    setBusy(true); setError(''); setNotice('');
    try { await task(); }
    catch (e: any) { setError(e?.message || 'The AI request could not be completed. Please try again.'); }
    finally { setBusy(false); }
  };

  const parseBrief = () => run(async () => {
    if (!brief.trim()) throw new Error('Describe what you need first.');
    const result = await apiFetch('/api/ai/parse-brief', { method: 'POST', body: JSON.stringify({ prompt: brief }) });
    setParsed(result.parsed || null);
    setNotice('Your sourcing brief has been structured.');
  });

  const findMatches = () => run(async () => {
    if (!brief.trim()) throw new Error('Enter a sourcing requirement first.');
    const result = await apiFetch('/api/ai/match', { method: 'POST', body: JSON.stringify({ brief }) });
    setMatches(result.matches || []);
    setNotice('Matching businesses loaded from the NJS network.');
  });

  const discoverLeads = () => run(async () => {
    if (!leadQuery.trim()) throw new Error('Describe the businesses you want to discover.');
    const result = await apiFetch('/api/leads/generate', { method: 'POST', body: JSON.stringify({ query: leadQuery }) });
    setLeads(result.leads || []);
    setNotice(`Found ${result.total ?? (result.leads || []).length} businesses in the NJS network.`);
  });

  const buildProfile = () => run(async () => {
    if (!profileText.trim()) throw new Error('Add a short factual description of your business.');
    const result = await apiFetch('/api/ai/build-profile', { method: 'POST', body: JSON.stringify({ description: profileText }) });
    setProfileDraft(result.generated || null);
    setNotice('Your editable business profile draft is ready.');
  });

  const applyProfile = () => run(async () => {
    if (!profileDraft) return;
    const result = await updateBusinessProfile({
      businessDescription: profileDraft.businessSummary || profileText,
      industry: profileDraft.industry || businessProfile?.industry || '',
      businessType: profileDraft.businessType || businessProfile?.businessType || '',
      businessKeywords: Array.isArray(profileDraft.keywords) ? profileDraft.keywords : businessProfile?.businessKeywords || [],
    } as any);
    if (!result.success) throw new Error(result.error || 'Could not save your profile.');
    setNotice('Your business profile was updated.');
  });

  const createDraft = () => run(async () => {
    if (!goal.trim()) throw new Error('Describe the purpose of this outreach.');
    const result = await apiFetch('/api/ai/draft-outreach', {
      method: 'POST',
      body: JSON.stringify({ recipient: { name: recipient || 'Business contact', company: company || 'their company' }, goal, tone }),
    });
    setDraft(result.draft || result.content || '');
    setNotice('Outreach draft generated. Review it before using it.');
  });

  const saveDraft = () => run(async () => {
    if (!draft.trim()) throw new Error('Generate an outreach draft first.');
    await apiFetch('/api/outreach/save-draft', {
      method: 'POST',
      body: JSON.stringify({ leadName: recipient || company || 'Business contact', goal, tone, content: draft }),
    });
    setNotice('Draft saved to your NJS outreach drafts.');
  });

  const copy = async (value: string) => {
    try { await navigator.clipboard.writeText(value); setNotice('Copied to clipboard.'); }
    catch { setError('Clipboard access is unavailable in this browser.'); }
  };

  const selectTool = (id: ToolId) => { setActive(id); setError(''); setNotice(''); };

  return (
    <main className="mx-auto w-full max-w-7xl space-y-6 pb-12">
      <section className="relative overflow-hidden rounded-3xl bg-[#17120f] px-6 py-8 text-white sm:px-9 sm:py-10">
        <div className="pointer-events-none absolute -right-16 -top-24 h-72 w-72 rounded-full bg-orange-500/20 blur-3xl" />
        <div className="relative flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1.5 text-xs font-semibold text-orange-200">
              <Sparkles size={14} /> NJS INTELLIGENCE
            </div>
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Your business, with an AI partner.</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-white/70 sm:text-base">
              One workspace for sourcing, finding relevant businesses, improving your profile and preparing better B2B conversations.
            </p>
          </div>
          <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-white/80">
            <div className="rounded-xl bg-orange-500/20 p-2 text-orange-300"><WandSparkles size={21} /></div>
            <div><div className="font-semibold text-white">OpenAI-powered tools</div><div className="mt-0.5 text-xs text-white/60">Available through your NJS account</div></div>
          </div>
        </div>
      </section>

      {(error || notice) && <div className={`flex items-start gap-2 rounded-xl border px-4 py-3 text-sm ${error ? 'border-red-200 bg-red-50 text-red-700' : 'border-green-200 bg-green-50 text-green-800'}`}>
        {error ? <AlertCircle size={18} className="mt-0.5 shrink-0" /> : <CheckCircle2 size={18} className="mt-0.5 shrink-0" />}
        <span>{error || notice}</span>
      </div>}

      <div className="grid gap-5 lg:grid-cols-[270px_minmax(0,1fr)]">
        <aside className="h-fit rounded-2xl border border-outline-variant/50 bg-white p-3 shadow-sm">
          <button onClick={() => selectTool('workspace')} className={`mb-2 flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-semibold ${active === 'workspace' ? 'bg-orange-50 text-primary' : 'text-on-surface-variant hover:bg-surface-container-low'}`}>
            <Sparkles size={18} /> AI workspace <ChevronRight size={16} className="ml-auto" />
          </button>
          <div className="px-3 pb-2 pt-3 text-[10px] font-bold uppercase tracking-[.16em] text-on-surface-variant/70">Your AI tools</div>
          <div className="space-y-1">
            {tools.map(tool => {
              const Icon = tool.icon;
              return <button key={tool.id} onClick={() => selectTool(tool.id)} className={`flex w-full items-start gap-3 rounded-xl px-3 py-3 text-left transition ${active === tool.id ? 'bg-orange-50 text-primary' : 'text-on-surface-variant hover:bg-surface-container-low'}`}>
                <Icon size={18} className="mt-0.5 shrink-0" />
                <span className="min-w-0"><span className="block text-sm font-semibold">{tool.title}</span><span className="mt-0.5 block text-xs leading-4 opacity-70">{tool.description}</span></span>
              </button>;
            })}
          </div>
          <div className="mt-4 rounded-xl bg-surface-container-low p-3 text-xs leading-5 text-on-surface-variant">
            <strong className="text-on-surface">A note about discovery</strong><br />
            Lead discovery currently searches businesses registered on NJS. External web prospecting and sending emails require additional integrations.
          </div>
        </aside>

        <section className="min-w-0 rounded-2xl border border-outline-variant/50 bg-white p-5 shadow-sm sm:p-7">
          {active === 'workspace' && <>
            <div className="mb-6"><p className="text-xs font-bold uppercase tracking-widest text-primary">AI command centre</p><h2 className="mt-1 text-2xl font-bold text-on-surface">What are we working on today?</h2><p className="mt-2 text-sm text-on-surface-variant">Choose a tool to get started. Your existing NJS business data stays connected to the workspace.</p></div>
            <div className="grid gap-3 sm:grid-cols-2">
              {tools.map(tool => { const Icon = tool.icon; return <button key={tool.id} onClick={() => selectTool(tool.id)} className="group rounded-2xl border border-outline-variant/50 p-5 text-left transition hover:border-primary/50 hover:bg-orange-50/50">
                <div className="mb-4 flex items-center justify-between"><span className="rounded-xl bg-orange-50 p-2.5 text-primary"><Icon size={21} /></span><ArrowRight size={17} className="text-on-surface-variant transition group-hover:translate-x-1 group-hover:text-primary" /></div>
                <h3 className="font-bold text-on-surface">{tool.title}</h3><p className="mt-1 text-sm leading-5 text-on-surface-variant">{tool.description}</p>
              </button>; })}
            </div>
            <div className="mt-5 rounded-2xl bg-surface-container-low p-5"><div className="flex items-center gap-2 font-semibold text-on-surface"><BriefcaseBusiness size={18} /> Connected business</div><p className="mt-1 text-sm text-on-surface-variant">{businessProfile?.businessName || 'Complete your business profile'}{businessProfile?.industry ? ` · ${businessProfile.industry}` : ''}</p></div>
          </>}

          {active === 'sourcing' && <>
            <ToolHeader icon={<Package size={20}/>} title="Sourcing assistant" description="Describe what your business needs. NJS AI will extract the key details into a structured brief." />
            <label className={labelClass}>Describe your sourcing requirement</label>
            <textarea className={`${inputClass} min-h-36 resize-y`} value={brief} onChange={e => setBrief(e.target.value)} placeholder="Example: We need 2,000 food-grade glass jars, delivered to Lagos within 8 weeks. Suppliers should support custom labelling..." />
            <div className="mt-4 flex flex-wrap gap-2"><ActionButton onClick={parseBrief} busy={busy}>Structure my brief</ActionButton><button onClick={() => setBrief('We need 2,000 food-grade glass jars with custom labelling, delivered to Lagos within 8 weeks.')} className="rounded-xl border border-outline-variant px-4 py-2.5 text-sm font-semibold text-on-surface-variant">Use example</button></div>
            {parsed && <ResultPanel title="Structured sourcing brief" data={parsed} onCopy={() => copy(JSON.stringify(parsed, null, 2))} />}
          </>}

          {active === 'matching' && <>
            <ToolHeader icon={<Target size={20}/>} title="Business matching" description="Find relevant businesses in the NJS network using your sourcing brief." />
            <label className={labelClass}>What kind of business are you looking for?</label>
            <textarea className={`${inputClass} min-h-32 resize-y`} value={brief} onChange={e => setBrief(e.target.value)} placeholder="Describe the supplier, buyer, manufacturer or partner you want to find..." />
            <div className="mt-4"><ActionButton onClick={findMatches} busy={busy}><Search size={16}/> Find NJS matches</ActionButton></div>
            {matches.length > 0 && <div className="mt-6 space-y-3"><h3 className="font-bold text-on-surface">{matches.length} matching businesses</h3>{matches.map((item, i) => <BusinessResult key={item.id || i} item={item.business || item} score={item.score} />)}</div>}
            <p className="mt-4 text-xs text-on-surface-variant">Matching currently ranks registered NJS profiles. AI-based semantic ranking is a backend upgrade still required; this interface does not claim keyword ranking is AI reasoning.</p>
          </>}

          {active === 'profile' && <>
            <ToolHeader icon={<Building2 size={20}/>} title="Business profile builder" description="Generate an editable profile draft from facts about your company. Review everything before saving." />
            <label className={labelClass}>Tell us about your business</label>
            <textarea className={`${inputClass} min-h-36 resize-y`} value={profileText} onChange={e => setProfileText(e.target.value)} placeholder="What does your business do? What products or services do you offer? Who do you serve? Which markets do you operate in?" />
            <div className="mt-4"><ActionButton onClick={buildProfile} busy={busy}>Build my profile</ActionButton></div>
            {profileDraft && <div className="mt-6 rounded-2xl border border-outline-variant/60 p-5"><div className="flex flex-wrap items-center justify-between gap-3"><h3 className="font-bold text-on-surface">Generated profile draft</h3><button onClick={() => copy(JSON.stringify(profileDraft, null, 2))} className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary"><Copy size={14}/> Copy JSON</button></div><p className="mt-3 text-sm leading-6 text-on-surface">{profileDraft.businessSummary}</p><div className="mt-4 grid gap-3 sm:grid-cols-2"><Preview label="Industry" value={profileDraft.industry}/><Preview label="Business type" value={profileDraft.businessType}/><Preview label="Products" value={profileDraft.products}/><Preview label="Services" value={profileDraft.services}/><Preview label="Capabilities" value={profileDraft.capabilities}/><Preview label="Keywords" value={profileDraft.keywords}/></div><button onClick={applyProfile} disabled={busy} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50"><Save size={16}/> Apply supported fields to my profile</button><p className="mt-2 text-xs text-on-surface-variant">Only description, industry, business type and keywords are saved by this action. Review the remaining generated suggestions before adding them manually.</p></div>}
          </>}

          {active === 'leads' && <>
            <ToolHeader icon={<Users size={20}/>} title="Lead discovery" description="Search the NJS business network for companies relevant to your target market." />
            <label className={labelClass}>Describe your ideal lead</label>
            <textarea className={`${inputClass} min-h-32 resize-y`} value={leadQuery} onChange={e => setLeadQuery(e.target.value)} placeholder="Example: Nigerian food distributors and wholesalers serving supermarkets..." />
            <div className="mt-4"><ActionButton onClick={discoverLeads} busy={busy}><Search size={16}/> Discover NJS businesses</ActionButton></div>
            {leads.length > 0 && <div className="mt-6 space-y-3"><h3 className="font-bold text-on-surface">{leads.length} businesses found</h3>{leads.map((item, i) => <BusinessResult key={item.id || i} item={item} score={item.score}/>)}</div>}
            <p className="mt-4 text-xs text-on-surface-variant">This searches existing, completed NJS business profiles only. It does not crawl the public web or invent contact details.</p>
          </>}

          {active === 'outreach' && <>
            <ToolHeader icon={<Send size={20}/>} title="Outreach studio" description="Prepare a relevant first message for a business conversation. You stay in control of sending it." />
            <div className="grid gap-4 sm:grid-cols-2"><div><label className={labelClass}>Recipient name</label><input className={inputClass} value={recipient} onChange={e => setRecipient(e.target.value)} placeholder="Contact name (optional)"/></div><div><label className={labelClass}>Recipient company</label><input className={inputClass} value={company} onChange={e => setCompany(e.target.value)} placeholder="Company name"/></div></div>
            <div className="mt-4"><label className={labelClass}>Outreach goal</label><textarea className={`${inputClass} min-h-24`} value={goal} onChange={e => setGoal(e.target.value)}/></div>
            <div className="mt-4"><label className={labelClass}>Tone</label><select className={inputClass} value={tone} onChange={e => setTone(e.target.value)}><option>Professional and warm</option><option>Formal</option><option>Friendly</option><option>Direct and concise</option></select></div>
            <div className="mt-4"><ActionButton onClick={createDraft} busy={busy}><WandSparkles size={16}/> Generate outreach draft</ActionButton></div>
            {draft && <div className="mt-6"><label className={labelClass}>Review and edit your draft</label><textarea className={`${inputClass} min-h-52 leading-6`} value={draft} onChange={e => setDraft(e.target.value)}/><div className="mt-3 flex flex-wrap gap-2"><button onClick={() => copy(draft)} className="inline-flex items-center gap-2 rounded-xl border border-outline-variant px-4 py-2.5 text-sm font-semibold"><Copy size={15}/> Copy</button><button onClick={saveDraft} disabled={busy} className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50"><Save size={15}/> Save draft</button><button onClick={createDraft} disabled={busy} className="inline-flex items-center gap-2 rounded-xl border border-outline-variant px-4 py-2.5 text-sm font-semibold"><RotateCcw size={15}/> Regenerate</button></div><p className="mt-3 text-xs text-on-surface-variant">NJS can generate and save drafts. Automatic email sending is not configured, so nothing is sent from this page.</p></div>}
          </>}
        </section>
      </div>
    </main>
  );
};

function ToolHeader({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return <div className="mb-6 flex items-start gap-3"><div className="rounded-xl bg-orange-50 p-3 text-primary">{icon}</div><div><h2 className="text-xl font-bold text-on-surface">{title}</h2><p className="mt-1 text-sm leading-5 text-on-surface-variant">{description}</p></div></div>;
}
function ActionButton({ children, onClick, busy }: { children: React.ReactNode; onClick: () => void; busy: boolean }) {
  return <button onClick={onClick} disabled={busy} className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:opacity-90 disabled:cursor-wait disabled:opacity-60">{busy ? <Loader2 size={16} className="animate-spin"/> : children}</button>;
}
function ResultPanel({ title, data, onCopy }: { title: string; data: any; onCopy: () => void }) {
  return <div className="mt-6 rounded-2xl border border-outline-variant/60 p-5"><div className="flex items-center justify-between gap-3"><h3 className="font-bold text-on-surface">{title}</h3><button onClick={onCopy} className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary"><Copy size={14}/> Copy</button></div><div className="mt-3 grid gap-3 sm:grid-cols-2">{Object.entries(data).map(([key, value]) => <Preview key={key} label={key.replace(/([A-Z])/g, ' $1')} value={value}/>)}</div></div>;
}
function Preview({ label, value }: { label: string; value: any }) {
  const display = Array.isArray(value) ? value.map(v => typeof v === 'string' ? v : v?.title || v?.name || JSON.stringify(v)).join(', ') : typeof value === 'object' && value !== null ? JSON.stringify(value) : String(value ?? '—');
  return <div className="rounded-xl bg-surface-container-low p-3"><div className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">{label}</div><div className="mt-1 break-words text-sm text-on-surface">{display || '—'}</div></div>;
}
function BusinessResult({ item, score }: { item: any; score?: any }) {
  const name = item.businessName || item.business_name || item.name || 'NJS business';
  const location = [item.city, item.country].filter(Boolean).join(', ');
  const description = item.businessDescription || item.business_description || item.industry || 'Business profile';
  return <article className="flex flex-col gap-3 rounded-xl border border-outline-variant/60 p-4 sm:flex-row sm:items-center sm:justify-between"><div className="min-w-0"><div className="flex items-center gap-2"><Building2 size={17} className="shrink-0 text-primary"/><h4 className="truncate font-semibold text-on-surface">{name}</h4></div><p className="mt-1 text-sm text-on-surface-variant">{description}</p>{location && <p className="mt-1 flex items-center gap-1 text-xs text-on-surface-variant"><Globe2 size={13}/>{location}</p>}{item.website && <a className="mt-1 inline-block text-xs font-semibold text-primary hover:underline" href={item.website} target="_blank" rel="noreferrer">Visit website</a>}</div>{score && <span className="shrink-0 rounded-full bg-orange-50 px-3 py-1 text-xs font-bold text-primary">{typeof score === 'string' ? score : `${score}%`}</span>}</article>;
}
