# NJS AI Assistant — replacement package

This package adds a unified NJS AI workspace and removes the separate AI Matches, AI Lead Generator and AI Outreach navigation entries.

## Apply it to the NJS project

1. Extract this ZIP into the root of your existing NJS project, preserving the `src` and `scripts` folders.
2. Run the integration script from the project root:
   `node scripts/apply-ai-assistant.mjs`
3. Install dependencies if needed: `bun install`
4. Validate: `bun run lint` and `bun run build`

The script updates `src/App.tsx` and `src/components/layout/Sidebar.tsx` while preserving the rest of those files. It also maps the old AI URLs to the new unified page so existing links do not break.

## Included tools

- Sourcing assistant — calls `/api/ai/parse-brief`
- Business matching — calls `/api/ai/match`
- Business profile builder — calls `/api/ai/build-profile`, then lets the user apply supported profile fields
- Lead discovery — calls `/api/leads/generate`
- Outreach studio — calls `/api/ai/draft-outreach` and `/api/outreach/save-draft`

## Important capability notes

The current backend still performs keyword-based business matching and registered-NJS-profile lead discovery. This interface labels those capabilities honestly; it does not pretend they are AI semantic ranking or public-web prospect crawling. Outreach generation and saving work through existing endpoints, but automatic email sending is not configured. The existing backend must be upgraded separately for AI semantic matching, external prospect discovery, and outbound email delivery.

This is a frontend replacement package, not a full repository backup. It does not modify billing, Paystack, subscriptions, authentication, database migrations, or Cloudflare Worker configuration.
